function Read_a2F_QE
%%% Function will post-process data from QE to user-friendly format
%%% Input files are a2F.dos* which are outputs of el-ph calculation of QE.
%%% As a result you will have 10 ASCII files with 2 coloums, which can be
%%% easily used for Excel or read by Solve_Eliashberg function and others

% clear all;
for i = 1:10                     % There are usually 10 a2F files corresponding to different smearing
    n = 0;
    filename = strcat('a2F.dos', num2str(i));                   % File for reading
    filename2 = fopen(strcat('a2F.dos.new', num2str(i)), 'w+'); % File for writing
    %     disp(filename);
    f= fopen(filename, 'r+');    % Reading files
    for t = 1:5
        fgetl(f);
    end
    while ~feof(f)
        tline = fgetl(f);
        if strfind(tline,'lambda')
            break
        end
        line = str2num(tline);
        diml = size(line);
        if line(1) ~=0 & diml < 3       % Extract lambda values from file
            n = n +1;
            elf(n,:) = line;
            % Print data in the new file
            fprintf(filename2, '%s\t%s\n', num2str(elf(n,1)), num2str(elf(n,2)));
        else
%             fprintf(filename2, '%s\n', num2str(line));
        end
    end
end

fclose all;
