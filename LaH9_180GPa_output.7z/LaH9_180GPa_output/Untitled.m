clear all
close all

a2F1 = load ('a2F.dos1');
l1=length(a2F1);

plot(a2F1(:,1),a2F1(:,2));
hold on

a2F2 = load ('a2F.dos2');
l1=length(a2F1);

plot(a2F2(:,1),a2F2(:,2));
hold on

a2F3 = load ('a2F.dos3');
l1=length(a2F1);

plot(a2F3(:,1),a2F3(:,2));
hold on
